Assignment 0

Authors: Basil ..., Linard Büchler, Eric Buffle

Description on how the exercise was solved: 

from inside the build folder: 
/assignment_0/build 
inside the file 
../scenes/solid_color/solid_color.sce
the following line:
background 0 0 0
was changed as follows:
background 0 0 0.7
We then run the following command: 
./raytrace ../scenes/solid_color/solid_color.sce solid_color.tga
which saved a blue background in the file "solid_color.tga"
